function main() {
  var variable = 'Hello World!'

  console.log(variable)

  for (var i = 0; i < variable.length; i++) {
    console.log(variable[i])
  }
}

main()
