function sam() {
  var temp = 'Hello Sam!'

  console.log(temp)

  var variable = 'Hello World!'

  console.log(variable)

  for (var i = 0; i < variable.length; i++) {
    console.log(variable[i])
  }
}

sam()
